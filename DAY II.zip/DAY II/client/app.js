// Code Here

import React from 'react'; // ES 6
import ReactDOM from 'react-dom';
import Course from './course.component'
import ListOfButtons from './listofbuttons.coponent';
import ListOfCourses from './listofcourses.component';
import Posts from './posts.component';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';
import Main from './main.component';

// var router = <Router history={browserHistory}>
//                             <Route path="/" component={Main} >
//                                     <IndexRoute component={ListOfCourses}></IndexRoute>
//                                     <Route path="/posts" component={Posts}>                                         
//                                     </Route>
//                             </Route>
//                     </Router>

// ReactDOM.render(router,document.getElementById('content'))


function FunctionalComponent(props){
    return <h1> {props.name}</h1>
}

ReactDOM.render(<FunctionalComponent name="My Functional component" />,document.getElementById('content'))






















// ReactDOM.render(<ListOfButtons 
//     initialCount={[10,20,30,40,50]} />,
//     document.getElementById('content'))

// ReactDOM.render(<ListOfCourses />,
//     document.getElementById('content'))

// ReactDOM.render(<Posts />,
//     document.getElementById('content'))