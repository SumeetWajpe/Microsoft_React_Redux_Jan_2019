import React from  'react';

export default class Button extends React.Component{
   
    constructor(props){
        super(props);
        this.state =  {currCount:this.props.count};
    }

   ClickEventHandler(){
        this.setState({currCount:this.state.currCount+1})
   }
   componentWillUnmount(){
       console.log('Clean up..')
   }
    render(){
        return <button className="btn btn-primary" onClick={this.ClickEventHandler.bind(this)}>{ this.state.currCount}</button>
    }
}

    


