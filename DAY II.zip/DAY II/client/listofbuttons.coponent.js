import React from  'react';
import Button from './button.component';

export default class ListOfButtons extends React.Component{
    constructor(props){
        console.log('constructor !');
        super(props);
    }
    componentWillMount(){ // set the initial state !
        this.state  ={list: this.props.initialCount};
        console.log('componentWillMount');
    }
    componentDidMount(){ // used to access DOM , AJAX
        console.log('componentDidMount');
    }
    shouldComponentUpdate(){
        console.log('shouldComponentUpdate !'); 
        console.log(arguments);

        if( arguments[1].list.length < 7){
            return true
        }
        return false;        
    }

    componentWillUpdate(){
        console.log('componentWillUpdate !');
    }
    componentDidUpdate(){
        console.log('componentDidUpdate !');
    }
    AddNewButton(){
        console.log('Setting state..')
        // add a new value in state list array !
        // access the textbox value !
        let theNewValue = this.refs.txtValue.value; 
        this.setState({list:[...this.state.list, +(theNewValue)]})
    }

    DeleteAButton(){
        console.log('Deleting...')
        let theValue = this.refs.txtValue.value; 
        let newStateList = this.state.list.filter(
            e=> e!= theValue
        );
        console.log(newStateList);
        this.setState({list:newStateList})
    }
    render(){
        console.log('render');
        console.log(this.state.list);

        var buttonsToBeCreated = this.state.list.map((b,i)=><Button key={Math.random()} count={b} />)
        return (<div>

Add A New Button : <input type="text" ref="txtValue" /> 

{/* <input type="button" className="btn btn-success" value="Add" />  */}

<button onClick={this.AddNewButton.bind(this)} className="btn btn-success btn-sm">
  Add  <span className="glyphicon glyphicon-plus"></span>
</button>

<button onClick={this.DeleteAButton.bind(this)} className="btn btn-danger btn-sm">
  Add  <span className="glyphicon glyphicon-trash"></span>
</button>

<br/>


            {buttonsToBeCreated}
        </div>)
    }
}

    


