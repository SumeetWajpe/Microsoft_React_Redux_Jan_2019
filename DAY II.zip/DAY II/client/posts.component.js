import React from 'react';
import axios from 'axios';

export default class Posts extends  React.Component{
    
    constructor(props){
        super(props);
        this.state = {allPosts:[]};
        // make ajaxified Request !
       let thePromise= axios.get('https://jsonplaceholder.typicode.com/posts');
       thePromise.then(
           (response)=> this.setState({allPosts:response.data})
           ,
           (err)=>console.log(err)           
       ); // eof then !
    }// eof ctor !
    
    render(){
        let postsToBeCreated = this.state.allPosts.map(p=><li>{p.title}</li>)
            return <div>
                <h1> All Posts </h1>
              <ul>{postsToBeCreated}</ul>  
                </div>
    }
}