import React from 'react';
import {Link} from 'react-router';

export default class Main extends  React.Component{
    
    render(){
      return <div>
                

<nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <a className="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul className="nav navbar-nav">  
      <li>  <Link to="/">List Of Courses</Link></li>
      <li>  <Link to="/posts">Posts</Link></li>
    </ul>
    <ul className="nav navbar-nav navbar-right">
      <li><a href="#"><span className="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="#"><span className="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>

                   {this.props.children}
                </div>
    }
}