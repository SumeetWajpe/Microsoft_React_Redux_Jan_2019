// Code Here

import React from 'react'; // ES 6
import ReactDOM from 'react-dom';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';
import Main from './components/main.component';
import Users from './components/users.component';
import UserDetails from './components/userdetails.component';
import {Provider} from 'react-redux';
import store from './store/store';
import app from './components/connect';

var router =<Provider store={store}>
                        <Router history={browserHistory}>
                            <Route path="/" component={app} >
                                    <IndexRoute component={Users}></IndexRoute>
                                    <Route path="/userdetails/:id" component={UserDetails}>                                         
                                    </Route>
                            </Route>
                    </Router>
                </Provider>  

ReactDOM.render(router,document.getElementById('content'))





















// ReactDOM.render(<ListOfButtons 
//     initialCount={[10,20,30,40,50]} />,
//     document.getElementById('content'))

// ReactDOM.render(<ListOfCourses />,
//     document.getElementById('content'))

// ReactDOM.render(<Posts />,
//     document.getElementById('content'))