import axios from 'axios';

export function IncrementFollowers(index){
    return {
        type:'INCREMENT_FOLLOWERS',
        index
    }
}

export function AddUser(){
    return {
        type:'ADD_USER'
    }
}

export function FilterUser(theUser){
    return {
        type:'FILTER_USER',
        theUser
    }
}

export function AddPost(){
    return {
        type:'ADD_POST'
    }
}

export function DeleteUser(){
    return {
        type:'DELETE_USER'
    }
}

export function GetAllUsers(){
    // make an ajax request
    // when received the response
    // dispatch an action !
    let request = axios.get('https://api.myjson.com/bins/t15w0')
    return dispatch =>{
            request.then(
                (response)=>{ console.log('Dispatching..');
                  dispatch({type:'FETCH_ALL_USERS',response:response.data})},
                (err)=>{ console.log(err)}
            )
    }

}