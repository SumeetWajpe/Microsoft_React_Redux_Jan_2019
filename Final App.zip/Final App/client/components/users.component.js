import React from  'react';
import UserThumbnail from './user.thumbnail';

export default class Users extends React.Component{
  
    render(){



            var usersToBeCreated = this.props.allusers.map((user,index)=> <UserThumbnail singleuser={user}
            userindex={index}
                {...this.props}
                key={user.id} />)
            
            return <div className="container">
                <div>
                <div className="jumbotron">
                            <h1> Github Users Component</h1>
                </div> 
                  <div className="input-group">
                    <div className="input-group-addon">
                            <span className="glyphicon glyphicon-search"></span>
                    </div>
                    <input type="text" className="form-control" ref="txtInput" 
                       onInput={()=>this.props.FilterUser(this.refs.txtInput.value)} />   
                </div>
                </div>
                    <div className="row">
                    {usersToBeCreated}
                    </div>
            </div>
       
    }
}

    


