import React from 'react';
import {Link} from 'react-router';

export default class Main extends  React.Component{
  componentDidMount(){
    this.props.GetAllUsers();// get all users
  }  

    render(){
      
      return <div>
                

<nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <a className="navbar-brand" href="#">Github Users</a>
    </div>
    <ul className="nav navbar-nav">  
      <li>  <Link to="/">All Users</Link></li>
      <li>  <Link to="/userdetails">User Details</Link></li>
    </ul>   
  </div>
</nav>

                   {React.cloneElement(this.props.children,this.props)}
                </div>
    }
}