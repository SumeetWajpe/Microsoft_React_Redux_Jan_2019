import React from  'react';
import {Link} from 'react-router';

export default class UserThumbnail extends React.Component{
  
    
    render(){
            
            return <div className="col-md-3 column userbox">
            
            <Link to={`/userdetails/${this.props.singleuser.id}`}>            
                <img src={this.props.singleuser.avatar_url} className="img-thumbnail"/>
            </Link>
            <div className="usertitle">{this.props.singleuser.type}</div>
                <div className="userrow">
                     <div className="pull-right">
                        <button  className="btn btn-danger" 
                        onClick={this.props.IncrementFollowers.bind(null,this.props.userindex)} >
                                        {this.props.singleuser.followers}
                                        <span className="glyphicon glyphicon-user">

                                        </span>
                        </button>
            </div>
            <div className="usertext">{this.props.singleuser.login}</div>
            </div>
            </div>
        
       
    }
}

    


