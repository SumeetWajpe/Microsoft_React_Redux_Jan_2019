import React from  'react';

export default class UserDetails extends React.Component{
  
    render(){
        
        // Fetch the id from Url !
        let userId =  this.props.params.id;
        let currUser = this.props.allusers.find(
            u=> u.id == userId
        );
        var index = this.props.allusers.findIndex(
            u=> u.id == userId
        );
            return <div className="container">
                    <div className="row">
                        <div className="col-md-10">
                            <img src={currUser.avatar_url} className="img-thumbnail"/>
                        </div>    
                        <div className="col-md-2">
                        <button className="btn btn-success"  onClick={()=> this.props.history.push('/')}>
                          Simon  Go Back !
                        </button>
                        </div>                    
                    </div>
                    <div className="row">
                        <div className="col-md-6">
                        <h1> Name :  {currUser.login}</h1>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-6">
                        <h1> Type: {currUser.type}</h1>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-6">
                        <button  className="btn btn-danger" 
                        onClick={this.props.IncrementFollowers.bind(null,index)} >
                                        {currUser.followers}
                                        <span className="glyphicon glyphicon-user">

                                        </span>
                        </button>
                        </div>
                    </div>
                    
                </div>
       
    }
}

    


