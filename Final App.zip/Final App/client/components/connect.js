import { connect } from "react-redux";
import Main from "./main.component";
import { bindActionCreators } from "redux";
import * as allimportedactions from '../actions/allactions'

function mapDispatchToProps (dispatcher){

    return bindActionCreators(allimportedactions,
        dispatcher);
}

// provider to pass the store as first argument
function mapStateToProps(storeData){
    return{
        allusers:storeData.users,
        allposts:storeData.posts
    }
}
// app is a Wrapper component = Main + props
var app = connect(mapStateToProps,
    mapDispatchToProps)(Main);

    export default app;