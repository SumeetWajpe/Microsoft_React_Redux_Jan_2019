import { combineReducers } from "redux";
import users from './users.reducer';
import posts from './posts.reducer';


var rootReducer = combineReducers({
    users:users,
    posts:posts
});

export default rootReducer;


// Enhanced Object Literal (ES6)

// var name = "Microsoft";

// var company = {name}