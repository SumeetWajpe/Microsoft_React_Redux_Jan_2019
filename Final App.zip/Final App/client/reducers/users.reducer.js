export default function users(defStore=[],action){
        switch(action.type){
                case 'INCREMENT_FOLLOWERS':
                //console.log('Within users reducer -> INCREMENT_FOLLOWERS ')
                //console.log(defStore);
                // Biz logic to update the store !
                // return an updated store !

                // index

                        return [
                              ...defStore.slice(0,action.index) ,
                              {...defStore[action.index],
                                followers:defStore[action.index].followers + 1} ,
                              ...defStore.slice(action.index+1)
                               ];  
                case 'ADD_USER':
                console.log('Within users reducer -> ADD_USER ')

                // Biz logic to update the store !
                // return an updated store !
                return defStore;
                case 'DELETE_USER':
                // Biz logic to update the store !
                // return an updated store !
                return defStore;
                case 'FETCH_ALL_USERS':                
                        return action.response;
                case 'FILTER_USER':                       
                               let theuserToBeShown = action.theUser;      
                               
                               if(theuserToBeShown == ''){
                                        return defStore;
                               }                               
                               return defStore.filter( u=> theuserToBeShown == u.login);
               

                        //        console.log('Username : ' + theuserToBeShown);
                        //        console.log(defStore.filter( u=> theuserToBeShown == u.login))


                default:             
                return defStore;
        }
}