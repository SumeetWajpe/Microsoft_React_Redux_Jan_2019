export default function posts(defStore=[],action){
   

    switch(action.type){
        case 'ADD_POST':
            console.log('Within Posts Reducer !');
            console.log(action.type);    
            console.log(defStore);
            // Biz logic for updating the store !
        return defStore;
        default:
        return defStore;
       
    }

 
}