// Code Here

import React from 'react'; // ES 6
import ReactDOM from 'react-dom';
import Course from './course.component'
import ListOfButtons from './listofbuttons.coponent';

ReactDOM.render(<ListOfButtons 
    initialCount={[10,20,30,40,50]} />,
    document.getElementById('content'))