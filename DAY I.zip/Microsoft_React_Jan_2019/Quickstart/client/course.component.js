import React from  'react';

export default class CourseComponent extends React.Component{
    render(){
        return <h1> React </h1>
    }
}

    


