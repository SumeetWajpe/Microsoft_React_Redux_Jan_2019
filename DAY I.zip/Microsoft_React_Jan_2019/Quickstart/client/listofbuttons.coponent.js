import React from  'react';
import Button from './button.component';

export default class ListOfButtons extends React.Component{
    constructor(props){
        super(props);
        this.list = this.props.initialCount;
    }

    render(){
        var buttonsToBeCreated = this.list.map(b=><Button count={b} />)
        return (<div>
            {buttonsToBeCreated}
        </div>)
    }
}

    


